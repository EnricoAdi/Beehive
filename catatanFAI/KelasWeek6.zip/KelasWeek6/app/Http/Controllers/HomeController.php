<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{
    private int $camelCase;
    // Ini PascalCase
    public function HomeIndex()
    {
        // try {
            // DB::select("SELECT * FROM STTS");
        // } catch (\Throwable $th) {
        //     //throw $th;
        // }
        $html = "<html>
        <title>Hello World</title><body>Hello World, This is my first controller with Method!
        <br/>
        <form action=".url("/search").">
        <label>Kata Kunci</label>
        <input type=\"text\" name=\"cari\">
        <button type=\"submit\">Cari</button>
        </form>
        </body></html>";
        // ini yang OOP
        return new Response($html);
        // return response($html)
    }

    public function ResultSearch(Request $request)
    {
        $search = $request->input("cari");
        return new Response("Kata cari : ".$search."<br/>Isinya : ".env("CACHE_DRIVER"));
    }

    public function FormCookie() {
        $html = "<html><form action='".url("/cookie")."' method='post'>
        ".csrf_field()."
        <label>Nilai Cookie</label>
        <input type=\"text\" name=\"cookie\">
        <button type=\"submit\">Kirim</button>
        </form>
        </body></html>";
        return new Response($html);
    }

    public function FormSetCookie(Request $request)
    {
        $cookie = $request->input("cookie");
        return redirect("/cookie/show")
            ->cookie("cookie", $cookie, 10000);
    }

    public function CookieShow(Request $request)
    {
        $cookie = $request->cookie("cookie");
        return new Response("Isinya : ".$cookie);
    }

    public function HomeBlade(Request $request)
    {
        // Ini maksa user ke halaman lain kalau belum login
        if ($request->cookie("userid") == null)
        {
            return Redirect::to("/");
        }

        $iniJudul = "Home blade example";
        $iniContent = "SAYA BELAJAR LARAVEL. HEBAT!";
        return view("home", [
            "judul" => $iniJudul,
            "content" => $iniContent,
        ]);
    }


}
