<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
use stdClass;

class BarangController extends Controller
{
    public function TambahBarang(Request $request)
    {
        $request->validate([
            "kode" => 'required|min:5|string',
            "stok" => 'numeric',
            "harga" => 'numeric',
        ]);

        // Otomatis pakai default connection mysql
        DB::beginTransaction();
        $result = DB::insert("INSERT INTO barang VALUES(:kode, :nama, :stok, :harga)", [
            "kode" => $request->input("kode"),
            "nama" => $request->input("nama"),
            "stok" => $request->input("stok"),
            "harga" => $request->input("harga"),
        ]);
        $file =  $request->file("gambar");
        $ext = $file->extension();
        $fileResult = $file->storeAs("/barang", $request->input("kode") . "." . $ext,"public");
        if ($result && $fileResult!==false) {
            DB::commit();
            return redirect()->back()->with("success", "Berhasil Tambah Barang " . $request->input("kode"));
        } else {
            DB::rollBack();
            return redirect()->back()->with("error", "Gagal Tambah Barang " . $request->input("kode"));
        }
    }

    public function ListBarang()
    {
        $data = DB::table("barang")->paginate(3);
        // $data->render();
        return view("forms.barang.list", [
            "data" => $data
        ]);
    }

    public function FormEdit($id)
    {
        $d = DB::table("barang")
            ->where("kode_barang", "=", $id)
            // First adalah sebuah method untuk get() terus
            // ambil index paling atas
            ->first();
        // Menghentikan sebelum memunculkan halaman
        if ($d == null) abort(404, "Barang tidak ditemukan!");
        return View::make("forms.barang.edit", [
            "d" => $d
        ]);
    }

    public function EditBarang($id, Request $request)
    {
        $request->validate([
            "kode" => 'required|min:5|string',
            "stok" => 'numeric',
            "harga" => 'numeric',
        ]);

        // Otomatis pakai default connection mysql
        $result = DB::table("barang")
            ->where("kode_barang", "=", $id); // ini oldnya!
        // dd($result->toSql()); // print builder
        $d = $result->first();
        if ($d == null) abort(403, "Barang tidak ditemukan!");

        $result = $result->update([
            "kode_barang" => $request->input("kode"),
            "nama_barang" => $request->input("nama"),
            "stok_barang" => $request->input("stok"),
            "harga_barang" => $request->input("harga"),
        ]);

        if ($result) {
            return redirect("/master/barang")->with("success", "Berhasil Update Barang " . $request->input("kode"));
        } else {
            return redirect()->back()->with("error", "Gagal Update Barang " . $request->input("kode"));
        }
    }

    public function TanyaHapusBarang($id)
    {
        $d = DB::table('barang')
            ->where("kode_barang", "=", $id)
            ->get(["nama_barang"]);
        $nama = $d[0]->nama_barang;
        return view("forms.barang.hapus", [
            "id" => $id,
            "nama" => $nama
        ]);
    }

    public function HapusBarang($id)
    {
        $result = DB::table('barang')
            ->where("kode_barang", "=", $id)
            ->delete();
        if ($result)
            return redirect("/master/barang")
                ->with("success", "berhasil hapus $id");
        else
            return redirect("/master/barang")
                ->with("error", "Gagal hapus $id");
    }

    public function SearchBarang(Request $request)
    {
        $hasil = Barang::where("nama_barang","LIKE","%".$request->input("q")."%")->get();
        $resp = new stdClass();
        $resp ->status = true;
        $resp->code = "OK";
        $resp->data = new stdClass();
        $resp->data->barang = $hasil;
        return response()->json($resp);
    }
}
