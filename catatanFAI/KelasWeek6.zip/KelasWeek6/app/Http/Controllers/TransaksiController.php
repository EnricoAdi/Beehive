<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\Dtrans;
use App\Models\Htrans;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Session;
use stdClass;

class TransaksiController extends Controller
{
    public function FormTambah(Request $request)
    {
        $barang = Barang::get();
        $data = $request->session()->get("detail_trans", collect([]));

        return view("trans.add", [
            "data" => $data,
            "barang" => $barang
        ]);
    }

    public function ListTransaksi(Request $request)
    {
        /** @var Htrans */
        $data = Htrans::where("id_user",$request->user()->username)->get();
        // return view("trans.list", [
        //     "data" => $data
        // ]);
        return view("trans.list", compact("data"));
    }
    public function DetailTransaksi(Request $request, int $id)
    {

        $h = Htrans::findOrFail($id); //kalau gk ketemu di abort
        $auth = Gate::inspect("view",$h);
        if(!$auth->allowed()){
            abort(403,$auth->message());
        }
        return view("trans.detail", compact("h"));
    }
    public function ProsesTambah(Request $request)
    {
        if ($request->input("btnAction") == "tambah-barang")
            return $this->TambahDetail($request);
        else if ($request->input("btnUpdateBarang") != null)
            return $this->UpdateDetail($request);
        else if ($request->input("btnAction") == "tambah-trans")
            return $this->ProsesTrans($request);
        else
            return $this->HapusDetail($request);
    }
    private function ProsesTrans(Request $request)
    {
        $data = $request->session()->get("detail_trans", collect([]));
        //Lalu kita kirim ke transaksi
        DB::beginTransaction(); //ini open transaction
        $result = true;
        $header = new Htrans();
        $header->id_user = Auth::id(); //dapat username nya
        $header->nama_pelanggan = $request->input("nama_pelanggan");
        $header->catatan = $request->input("catatan");
        $header->diskon = 0;
        $header->total = 0;
        $result &= $header->save();
        //waktu di save ini id nya sudah keisi
        $hID = $header->id;
        $total = 0;
        foreach ($data as $d) {
            //create new object
            $dt = new Dtrans();
            $dt->id_barang = $d->id;
            $dt->id_header = $hID;
            $dt->jumlah = $d->jumlah;
            $dt->harga = $d->harga;

            $result &= $dt->save();
            $total += $d->jumlah * $d->harga; //increment total
        }
        //update total trans
        $header->total = $total;
        $result &= $header->save();
        if ($result) {
            DB::commit(); //jangan lupa di commit

            //session clear
            Session::forget("detail_trans");
            return redirect()->back()->with("success", "Berhasil tambah trans id $hID");
        } else {
            DB::rollBack();
            return redirect()->back()->with("error", "GAGAL INSERT TRANSAKSI");
        }
    }
    private function TambahDetail(Request $request)
    {
        $data = $request->session()->get("detail_trans", collect([]));
        $barang = Barang::find($request->input("id_barang"));
        $b = new stdClass();
        //catat id barang
        $b->id = $request->input("id_barang");
        $b->nama_barang = $barang->nama_barang;
        $b->jumlah = $request->input("jumlah");
        $b->harga = $barang->harga_barang;
        $data[] = $b;
        $request->session()->put("detail_trans", $data);

        return redirect()->back()
            ->with("success", "Berhasil tambah detail");
    }

    private function HapusDetail(Request $request)
    {
        $data = $request->session()->get("detail_trans", collect([]));
        unset($data[$request->input("btnHapusBarang")]);
        return redirect()->back()
            ->with("success", "Berhasil hapus detail");
    }

    private function UpdateDetail(Request $request)
    {
        $data = $request->session()->get("detail_trans", collect([]));
        $i = $request->input("btnUpdateBarang");
        $d = $data[$i];
        $d->jumlah = $request->input("jumlahd")[$i];
        return redirect()->back()
            ->with("success", "Berhasil update detail");
    }
    public function Delete($id)
    {
        /** @var HTrans */
        $d = Htrans::findOrFail($id);

        $auth = Gate::inspect("delete",$d);
        if(!$auth->allowed()){
            abort(403,$auth->message());
        }

        $d->delete();

        return redirect("/transaksi")->with("success", "Berhasil delete $id");
    }
}
