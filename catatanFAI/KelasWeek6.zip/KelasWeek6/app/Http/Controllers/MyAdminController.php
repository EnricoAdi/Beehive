<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MyAdminController extends Controller
{
    public function GetUserConfig()
    {
        // Panggil koneksi berbeda
        $db = DB::connection("phpmyadmin");

        $result = $db->table("pma__userconfig")
            ->get();
        // Result dari builder dan query untuk select
        // selalu berupa PHP Object! kalau akses isinya harus
        // pakai -> property
        echo $result[0]->username;
        dd($result);
    }
}
