<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function LoginForm()
    {
        return view("forms.form-input");
    }

    public function LoginAction(Request $request)
    {
        $user = $request->input("user");
        $pass = $request->input("pass");

        if (Auth::attempt([
            "username" => $user,
            "password" => $pass,
        ])) {
            // return (new Response("Berhasil Login!"))
            // ->cookie("userid", "admin",  (10*24*60));
            return redirect()->intended()->with("success", "Berhasil Login");
        }
        // else if (Auth("manager")->attempt([
        //     "username" => $user,
        //     "password" => $pass,
        // ]))
        // {
        //     return redirect("/master/barang/search")->with("success","Berhasil Login");
        // }
        else {
            return new Response("Pass salah! <a href='" . url("/login") . "'>Login</a>");
        }
    }
}
