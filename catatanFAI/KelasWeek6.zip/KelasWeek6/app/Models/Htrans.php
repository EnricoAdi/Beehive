<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Htrans extends Model
{
    use HasFactory, SoftDeletes;
    public $timestamps = true;
    public $casts = [
        'created_at' => 'datetime:d-m-Y H:i',
        'updated_at' => 'datetime:d-m-Y H:i'
    ];
    public function detail()
    {
        return $this->hasMany(Dtrans::class, "id_header", "id");
    }
}
