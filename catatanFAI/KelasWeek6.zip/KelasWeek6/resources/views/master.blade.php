<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FAI | @yield("title")</title>
    {{-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous"> --}}
    <link rel="stylesheet" href="{{url('/asset/bootstrap.css')}}">
</head>
<body>
<div class="container">
    <ul>
        <li><a href="{{url()->current()}}?lang=id">Indonesia</a></li>
        <li><a href="{{url()->current()}}?lang=en">English</a></li>
        <li><a href="{{url("/master/barang")}}">Barang</a></li>
        <li><a href="{{url("/home")}}">Home</a></li>
        <li><a href="{{url("master/barang/search")}}">Search with ajax</a></li>
        <li><a href="{{url("/transaksi")}}">Transaksi</a></li>
    </ul>
    <h1>
    @section("header")
    Master&nbsp;
    @show
    </h1>
    @include("message")
    @yield("content")
</div>
</body>
</html>
