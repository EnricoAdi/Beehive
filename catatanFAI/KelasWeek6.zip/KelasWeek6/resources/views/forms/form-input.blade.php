@extends("master")
@section("title", "Form Login")

@section("header")
{{-- @parent  --}}Login
@endsection

@section("content")
<form action="{{ url("/login") }}" method="post">
    @csrf
    <input type="text" name="user" class="form-control" placeholder="Username">
    <br>
    <input type="text" name="pass" class="form-control" placeholder="Password">
    <br>
    <button class="btn btn-primary" type="submit">Login</button>
</form>
@stop
