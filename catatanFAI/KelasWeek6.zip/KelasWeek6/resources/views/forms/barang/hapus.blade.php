@extends("master")
@section("title", "Form List Barang")

@section("header")
@parent Barang
@endsection

@section("content")
<h3>Apakah anda mau menghapus {{ $nama }}</h3>
<form action="{{ url('/master/barang/'.$id.'/delete') }}" method="POST">
@csrf
{{-- Ini untuk method spoofing! --}}
@method('DELETE')
<button type="submit" class="btn btn-danger">Hapus</button>
<a href="{{ url("/master/barang") }}" class="btn btn-primary">
    Kembali
</a>
</form>
@endsection
