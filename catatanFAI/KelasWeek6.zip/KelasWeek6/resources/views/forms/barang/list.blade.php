@extends("master")
@section("title", "Form List Barang")

@section("header")
@parent Barang
@endsection
@section("content")
<a href="{{ url("/master/barang/tambah") }}"
class="btn btn-primary">@lang("item.add")</a>
<table class="table table-striped">
<thead>
    <th>ID @lang("item.item")</th>
    <th>@lang("item.item_name")</th>
    <th>@lang("item.stock")</th>
    <th>@lang("item.price")</th>
    <th>@lang("item.img")</th>
    <th>Aksi</th>
</thead>
@if(count($data) <= 0)
<tr><td colspan="5">TIDAK ADA DATA!</td></tr>
@else
    @foreach ($data as $d)
    <tr>
        <td>{{ $d->kode_barang }}</td>
        <td>{{ $d->nama_barang }}</td>
        <td>{{ $d->stok_barang }}</td>
        <td>{{ $d->harga_barang }}</td>
        <td><img width="100px" src="{{ asset("/storage/barang/".$d->kode_barang.".jpg") }}"></td>
        <td>
            <a href="{{ url("/master/barang/"
                .$d->kode_barang) }}">
                Edit
            </a>
            <a href="{{ url("/master/barang/"
                .$d->kode_barang."/delete") }}">
                Delete
            </a>
        </td>
    </tr>
    @endforeach
@endif
</table>
{{$data->render()}}
@stop
