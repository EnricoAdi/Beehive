@extends('master')
@section('title', 'Cari Barang')

@section('header')
    Cari Barang
@endsection

@section('content')
    <div id="search-form">
        <form method="get" onsubmit="search(event)">
            <label for="">Kata Kunci</label> <br>
            <input type="text" name="q">
            <button type="submit">Cari</button>
        </form>
    </div>
    <div id="search-result">

    </div>

    <script>
        function search(e) {
            e.preventDefault(); //berhentikan form submit
            console.log(e);
            var q = new URLSearchParams({q:e.srcElement.elements.q.value});
            var req = new Request("{{ url('/master/barang/search-ajax') }}?"+q.toString(),{
                method:"GET",
            });
            fetch(req).then(
                (resp) => resp.json()
            ).then(
                (d) => renderHasil(d.data.barang)
            );
        }
        function renderHasil(data){
            var html = "";
            data.forEach(el => {
                html += `
                <div id="${el.kode_barang}">
                    Kode : ${el.kode_barang} <br>
                    Nama Barang : ${el.nama_barang} <br>
                    Harga : ${el.harga_barang} <br>
                    Stok : ${el.stok_barang} <br>
                </div>
                `;
            });
            document.getElementById("search-result").innerHTML = html;
        }
    </script>
@stop
