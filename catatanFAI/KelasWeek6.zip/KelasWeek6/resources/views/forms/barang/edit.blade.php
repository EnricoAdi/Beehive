@extends("master")
@section("title", "Form Edit Barang")

@section("header")
@parent Barang
@endsection

@section("content")
<form action="{{ url("/master/barang/".$d->kode_barang) }}" method="post">
    @csrf
    @method("PATCH")
    <input type="text" name="kode" class="form-control" placeholder="Kode Barang" value="{{old('kode') ?? $d->kode_barang}}">
    <br>
    <input type="text" name="nama" class="form-control" placeholder="Nama Barang" value="{{old('nama') ?? $d->nama_barang}}">
    <br>
    <input type="text" name="stok" class="form-control" placeholder="Stok Barang" value="{{old('stok') ?? $d->stok_barang}}">
    <br>
    <input type="text" name="harga" class="form-control" placeholder="Harga Barang" value="{{old('harga') ?? $d->harga_barang}}">
    <br>
    <button class="btn btn-info" type="submit">Update</button>
    <a href="{{ url("/master/barang") }}" class="btn btn-primary">Kembali</a>
</form>
@stop
