@extends("master")
@section("title", "Form Tambah Barang")

@section("header")
@parent Barang
@endsection

@section("content")
<form action="{{ url("/master/barang/tambah") }}" method="post" enctype="multipart/form-data">
    @csrf
    <input type="text" name="kode" class="form-control" placeholder="Kode Barang" value="{{old('kode')}}">
    <br>
    <input type="text" name="nama" class="form-control" placeholder="Nama Barang" value="{{old('nama')}}">
    <br>
    <input type="text" name="stok" class="form-control" placeholder="Stok Barang" value="{{old('stok')}}">
    <br>
    <input type="text" name="harga" class="form-control" placeholder="Harga Barang" value="{{old('harga')}}">
    <br>
    <input type="file" name="gambar" class="form-control"><br>
    <button class="btn btn-primary" type="submit">Tambah</button>
</form>
@stop
