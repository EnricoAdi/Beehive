@extends("master")
@section("title", "Form Login")

@section("header")
{{-- @parent  --}}Login
@endsection

@section("content")

@endsection
{{--
    composer dump-autoload -o
--}}
