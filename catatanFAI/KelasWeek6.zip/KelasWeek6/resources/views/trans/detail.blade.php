@extends('master')
@section('title', 'Transaksi')

@section('header')
    Detail Transaksi {{ $h->id }}
@endsection

@section('content')
    <form method="POST">
        @csrf
        {{-- Ini Headernya --}}
        <div class=row>
            {{-- <div class="col-6">
                <label>Tanggal</label>
                <input type="date" name="tanggal" class="form-control">
            </div> --}}
            <div class="col-6">
                <label>Nama Pelanggan</label>
                <b>{{ $h->nama_pelanggan }}</b>
            </div>
            <div class="col-6">
                <label>Catatan</label>
                <textarea class="form-control" name="catatan" cols="30" rows="10" readonly>
                    {{ $h->catatan }}
                </textarea>
            </div>
        </div>
        {{-- Ini Body --}}
        @php
            $total = 0;
        @endphp
        <table>
            <thead>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Total</th>
            </thead>
            <tbody>
                @foreach ($h->detail as $d)
                    {{--   ini dapetin detail yg dari model --}}
                    <tr>
                        <td>{{$d->barang->nama_barang}}</td>
                        <td>{{ $d->jumlah }}</td>
                        <td>{{ $d->harga }}</td>
                        <td>{{ $d->harga * $d->jumlah }}</td>

                    </tr>
                @endforeach
                <tr>
                    <td colspan="3">Total</td>
                    <td>{{ $h->total }}</td>
                </tr>
            </tbody>
        </table>
    @endsection
