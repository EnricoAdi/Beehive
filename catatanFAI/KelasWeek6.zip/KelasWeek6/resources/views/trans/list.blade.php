@extends('master')
@section('title', 'Form List Transaction')

@section('header')
    @parent Transaksi
@endsection

@section('content')
    <a href="{{ url('/transaksi/tambah') }}" class="btn btn-primary">Tambah Transaction</a>
    <table class="table table-striped">
        <thead>
            <th>ID</th>
            <th>Nama Pelanggan</th>
            <th>Total</th>
            <th>Tanggal</th>
            <th>Action</th>
            <th>Status</th>
        </thead>
        @if (count($data) <= 0)
            <tr>
                <td colspan="5">TIDAK ADA DATA!</td>
            </tr>
        @else
            @foreach ($data as $d)
                <tr>
                    <td>{{ $d->id }}</td>
                    <td>{{ $d->nama_pelanggan }}</td>
                    <td>{{ $d->total }}</td>
                    <td>{{ $d->created_at?->locale("id")->translatedFormat("l D d-m-Y H:i") }}</td>
                    <td>
                        <a href="{{ url('/transaksi/' . $d->id) }}">
                            Edit
                        </a>
                        <form action="{{ url('/transaksi/' . $d->id) }}" method="post">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">
                                Delete
                            </button>
                        </form>
                    </td>
                    <td>{{ $d->trashed() ? 'Deleted' : 'Masih ada :D' }}</td>
                </tr>
            @endforeach
        @endif
    </table>
@stop
