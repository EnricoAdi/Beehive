<div>
    {{-- {{ dd($d) }} --}}
<h4>{{ $d->nama_barang }}</h4>
&nbsp;&nbsp;&nbsp;
<input type="number" name="jumlahd[]" value="{{$d->jumlah}}">
<b>Harga {{ $d->harga }}</b>
<b>Sub Total {{ $d->jumlah * $d->harga }}</b>
<button name="btnUpdateBarang" type="submit" value="{{ $k }}" class="btn btn-primary">
    Update Barang
</button>
<button name="btnHapusBarang" type="submit" value="{{ $k }}" class="btn btn-primary">
    Hapus Barang
</button>
</div>
