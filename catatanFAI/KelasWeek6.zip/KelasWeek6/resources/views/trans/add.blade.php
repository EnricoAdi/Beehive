@extends('master')
@section('title', 'Transaksi')

@section('header')
    Transaksi
@endsection

@section('content')
    <form method="POST">
        @csrf
        {{-- Ini Headernya --}}
        <div class=row>
            <div class="col-6">
                <label>Tanggal</label>
                <input type="date" name="tanggal" class="form-control">
            </div>
            <div class="col-6">
                <label>Nama Pelanggan</label>
                <input type="text" name="nama_pelanggan" class="form-control">
            </div>
            <div class="col-6">
                <label>Catatan</label>
                <textarea class="form-control" name="catatan" cols="30" rows="10"></textarea>
            </div>
        </div>
        {{-- Ini Body --}}
        @if (count($data) > 0)
            @foreach ($data as $k => $d)
                @include('trans.detail-form-edit')
            @endforeach
        @endif
        @include('trans.detail-form')
        <button name="btnAction" type="submit" class="btn btn-primary" value="tambah-trans">
            Tambah
        </button>
    </form>
@endsection
