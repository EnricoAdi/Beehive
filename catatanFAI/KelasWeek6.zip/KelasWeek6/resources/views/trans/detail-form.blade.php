<div>
    {{-- {{dd($barang)}} --}}
<select name="id_barang">
@foreach ($barang as $b)
<option value="{{$b->kode_barang}}">
    {{ $b->nama_barang }} - {{ $b->harga_barang }}
</option>
@endforeach
</select>
&nbsp;&nbsp;&nbsp;
<input type="number" name="jumlah">
<button name="btnAction" type="submit" value="tambah-barang" class="btn btn-primary">
    Tambah Barang
</button>
</div>
