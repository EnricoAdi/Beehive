<?php

use App\Http\Controllers\BarangController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\MyAdminController;
use App\Http\Controllers\TransaksiController;
use App\Policies\HTransPolicy;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

// Route::get('/', function () {
//     return response('Hello World', 404);
// });

// Route::get("/", [\App\Http\Controllers\HomeController::class, "HomeIndex"]);
Route::get("/", [HomeController::class, "HomeIndex"]);
Route::get("/home", [HomeController::class, "HomeBlade"]);

Route::get('/stts', function () {
    return redirect("https://stts.edu");
});

Route::get("/search", [HomeController::class, "ResultSearch"]);

Route::get("/cookie", [HomeController::class, "FormCookie"]);
Route::post("/cookie", [HomeController::class, "FormSetCookie"]);
Route::get("/cookie/show", [HomeController::class, "CookieShow"]);

// Ini Login Part
Route::get("/login", [LoginController::class, "LoginForm"]);
// Jika mau lempar data ke view pakek Route::view, ga bisa
// Route::view("/login", "forms.form-input");
Route::post("/login", [LoginController::class, "LoginAction"])->name("login");
// End Login Part
Route::get("/logout", [LogoutController::class, "LogoutAction"]);

Route::get("/master/barang/search-ajax2", [BarangController::class, "SearchBarang"]);


// Route::prefix("/master/barang")->middleware("auth:manager")
// ->group(function(){
//     Route::view("/search", "forms.barang.search");
//     Route::get("/search-ajax", [BarangController::class, "SearchBarang"]);
// });

Route::prefix("/master/barang") 
->group(function(){
    Route::view("/search", "forms.barang.search");
    Route::get("/search-ajax", [BarangController::class, "SearchBarang"]);
});

Route::prefix("/")->middleware("auth")->group(function () {

    Route::prefix("/master")->group(function () {
        Route::prefix("/barang")->group(function () {
            Route::get("/", [BarangController::class, "ListBarang"]);
            Route::view("/tambah", "forms.barang.form-input");
            // Yang berID Setelahnya
            Route::get("/{id}/delete", [BarangController::class, "TanyaHapusBarang"]);
            Route::get("/{id}", [BarangController::class, "FormEdit"]);


            // Proses Data
            Route::post("/tambah", [BarangController::class, "TambahBarang"]);
            Route::patch("/{id}", [BarangController::class, "EditBarang"]);
            Route::delete("/{id}/delete", [BarangController::class, "HapusBarang"]);
        });
    });

    Route::prefix("/transaksi")->group(function () {
        Route::get("/", [TransaksiController::class, "ListTransaksi"]);
        Route::get("/tambah", [TransaksiController::class, "FormTambah"]);

        Route::get("/{id}", [TransaksiController::class, "DetailTransaksi"]);

        // Aksi Form nya
        Route::post("/tambah", [TransaksiController::class, "ProsesTambah"]);


        Route::delete("/{id}", [TransaksiController::class, "Delete"]);
    });
    Route::get('users', function () {
        // dump(Auth::id());
        // dump(Auth::check());
        // dd(Auth::user());
    });
});
Route::get("/conn", [MyAdminController::class, "GetUserConfig"]);
Route::get("/download/{loc}", function ($loc) {
    //HARUS DI RETURN
    try {
        return Storage::download("public/barang/" . $loc, "hasil.jpg");
    } catch (Exception) {
        abort(404);
    }
});
