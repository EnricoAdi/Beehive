<?php

namespace Database\Seeders;

use App\Models\Barang;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BarangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $barang = new Barang();
        $barang->kode_barang = "B0001";
        $barang->nama_barang = "Barang 1";
        $barang->stok_barang = "10";
        $barang->harga_barang = "100000";
        $barang->save();

        $barang = new Barang();
        $barang->kode_barang = "B0002";
        $barang->nama_barang = "Barang 2";
        $barang->stok_barang = "14";
        $barang->harga_barang = "100000";
        $barang->save();

        $barang = new Barang();
        $barang->kode_barang = "B0003";
        $barang->nama_barang = "Barang 3";
        $barang->stok_barang = "5";
        $barang->harga_barang = "100000";
        $barang->save();
    }
}
