<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $u = new User();
        $u->username = "admin";
        $u->password = password_hash("123",PASSWORD_DEFAULT);
        $u->email = "admin@stts.edu";
        $u->name = "Admin";
        $u->save();
    }
}
