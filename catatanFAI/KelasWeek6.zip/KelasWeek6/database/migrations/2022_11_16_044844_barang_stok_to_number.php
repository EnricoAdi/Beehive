<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('barang', function (Blueprint $table) {
            // $table->integer("stok_barang")->change();
            // $table->string("kode_barang")->primary();
            // $table->string("nama_barang");
            // $table->string("harga_barang");
            // $table->string("stok_barang");
            // $table->timestamps();
            // $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('barang', function (Blueprint $table) {
            // $table->string("stok_barang")->change();
        });
    }
};
